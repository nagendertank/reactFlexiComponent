import {add} from "./math";

console.log(add(10, 20));

let title = "Math";

if (true) {
    let title = "if cond";

}

console.log(title);


var xml = <div>
                <h1 id="id1"> Test</h1>
</div>;

