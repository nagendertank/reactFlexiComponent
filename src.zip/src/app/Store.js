import {createStore, applyMiddleware} 
                from "redux";

//redux-thunk middleware
//takes functions in the dispatch
//execute the funtion
import thunk from "redux-thunk";

//Reducer.js

const INITIAL_STATE = 1000;

function counterReducer(state=INITIAL_STATE, action) {
    console.log("Counter reducer", state, action);
    switch (action.type) {
        case 'INCREMENT': 
            return state + 1
        case 'DECREMENT':
            return state - 1
        default:
            return state;
    }
}

/////////reducer.js

//reducer manipulate the state
//store useful for storing state value
//returned by reducer


function mathReducer(state = 0, action) {
    switch(action.type) {
        case "ADD": return state + action.value;
        default:
        return state;
    }
}

import {combineReducers} from "redux";

import productReducer from "./product/Reducer";

var rootReducer = combineReducers({
    counterState: counterReducer,
    mathState : mathReducer,
    productState: productReducer
})

let store = createStore(rootReducer,
                        applyMiddleware(thunk));

store.subscribe ( ()=> {
    console.log("SUB 1", 
                    store.getState())
})


export default store;


var action = {
    type: 'INCREMENT'
}

//actions.js ends

//dispatch calls reducer
store.dispatch(action);

console.log("store value ", 
            store.getState())

store.dispatch(action);


console.log("store value ", 
            store.getState())

store.dispatch(action);

var state = store.getState();

//state has counterState, mathState
//state.counterState

console.log("store value ", 
            store.getState())

store.dispatch({
    type: 'DECREMENT'
})


console.log("store value ", 
            store.getState())



//actions.js
    //action creators

    function incrementAction() {
        return {
            type: 'INCREMENT'
        }
    }


action = incrementAction();

store.dispatch(action);

function actionFunction() {
    //thunk shall pass dispatch method
    //to this function
    return function(dispatch) {
        console.log("Called by redux middleware")
        
        dispatch({
            type: 'INCREMENT'
        })
    
    }
}


let actionFn = actionFunction();

store.dispatch(actionFn);

//
