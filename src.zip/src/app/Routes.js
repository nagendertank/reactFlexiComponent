import React from "react";

import {BrowserRouter as Router,
        Switch, 
        Route} from "react-router-dom";
 
import {App} from "./components/App";

import {Home} from "./components/Home";
import {Contact} from "./components/Contact";
import {About} from "./components/About";

import ProductRoutes from "./product/ProductRoutes";

export default function Routes (props) {
    return (
<Router >
<App>
    <Switch>
        <Route path="/" exact component={Home}>
        
        </Route>

        <Route path="/about" 
                component={About}>
        
        </Route>


        <Route path="/products">
            <ProductRoutes>

            </ProductRoutes>
        </Route>


        <Route path="/contact" 
                component={Contact}>
        
        </Route>

        
    </Switch>
</App>
</Router>
    )
}