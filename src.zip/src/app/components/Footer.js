import React from "react";

//functonal component 
//no life cycle methods

export default function Footer(props) {
    return (
        <div>
            {/* comments  */}
            Copyrights {props.company} @{props.year}
            <span> 
                    Likes : {props.likes}
            </span>

            <button onClick={()=> props.incr()} >
                +1
            </button>
        </div>
    )
}

Footer.defaultProps = {
    company: 'Wipro'
}