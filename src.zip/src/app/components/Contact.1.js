import React from "react";

import store from "../Store";

//stateful component
export class Contact extends React.Component {
   constructor(props) {
       super(props);

       this.state = {
           counter: 0
       }
   }

   componentDidMount() {
       this.handle = setInterval( () => {
           this.setState({
               counter : this.state.counter + 1
           })

           console.log("contact timer ", this.state.counter);
       }, 3000);
   }

   componentWillUnmount() {
      clearInterval(this.handle);
   }
   
    render() {
        return (
            <div>
                <h1>Contact page</h1>
                <h2>{this.state.counter}</h2>
            </div>
        )
    }
}