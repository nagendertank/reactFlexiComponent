import React from "react";

export class About extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            members: ['Member 1', 'Member 2'],
            name: ''
        }
    }

    componentDidMount() {
        //ref give access to real DOM

        this.para.textContent = "here are our great team"
    
        this.input.focus();
    }

    onChangeValue (e) {
        console.log(e.target.value);

        this.setState({
            name: e.target.value
        })
    }

    onAdd() {
        this.setState({
            members: [...this.state.members, 
                      this.state.name],
            name: ''
        })
    }


    render() {
        let list = this.state.members
                   .map  (m => (
                       <li key={m}>
                           {m}
                      </li>
                   ))

        return (
<div>
    <h1>About page</h1>

    <h2>Our Team </h2>

    <p  ref={ (elem) => this.para = elem}>
    </p>

    <input name="name" 
           ref = {(elem) => this.input = elem}
           value={this.state.name} 

           onChange={(e) => this.onChangeValue(e)}
     />
    <button  onClick={()=>this.onAdd()}>
        Add
    </button>

    <ul>
        {list}
    </ul>
</div>
        )
    }


    componentWillUnmount() {
        console.log("About shall be destroyed")
    }
}