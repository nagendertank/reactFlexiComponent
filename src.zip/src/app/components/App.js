import React from "react";

import {HashRouter as Router,
        Switch} from "react-router-dom";

import Header from "./Header";
import Footer from "./Footer";

export class App extends React.Component {

    render() {
        return (
    <div>
        <h1>App Comp</h1>

        <Header>
        </Header>
        
        {/* place holder for views  */}
        <main>
            {this.props.children}
        </main>

        <Footer>
        </Footer>

    </div>
        )
    }
}