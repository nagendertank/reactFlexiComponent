import React from "react";

import {Link} from "react-router-dom";

//only one default per file
//class component
export default class Header 
            extends React.Component {
            
    //1
    constructor() {
        super();

        console.log("HEader created");
    }

    //life cycle method
    //called before displaying
    //componet on real dom
    //2
    componentWillMount() {
        console.log("Component will mount");
    }

    //component is placed/mounted
    //on real browser DOM
    //4
    componentDidMount() {
        console.log("component did mount")
    }

    //3: 
    render() {
        console.log("header render");
        return (
            <div>
                <h2>{this.props.title}</h2>
                <span> 
                    Likes : {this.props.likes}
                </span>

                <div>
                    <Link to="/"> 
                        Home
                    </Link>

                    <Link to="/products">
                        Products
                    </Link>

                    <Link to="/contact">
                        Contact
                    </Link>

                    <Link to="/about">
                        About
                    </Link>

                </div>

            </div>
        )
    }

    //5.
    //called just before destorying 
    //component
    
    componentWillUnmount() {
        console.log("Component will unmount");
    }



    //props life cycle
    
    componentWillReceiveProps(props){
        console.log("will receive ", props);
    }

    //controll render method
    shouldComponentUpdate() {
        if (this.props.likes % 3 == 0)
            return true; //update ui
    
        return false;
    }

}