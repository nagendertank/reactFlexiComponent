import React from "react";

import store from "../Store";

//stateless component
export class Contact extends React.Component {
   constructor(props) {
       super(props);
   }

   componentDidMount() {

     this.unsubscribeFn = store.subscribe ( ()=> {
         console.log("Subscribe contact");
         this.forceUpdate();
     })



       this.handle = setInterval( () => {
            
           store.dispatch({
               type: 'INCREMENT'
           })

       }, 3000);
   }

   componentWillUnmount() {
      clearInterval(this.handle);

      //unsubscribe from store update
      this.unsubscribeFn();

   }
   
    render() {
        return (
            <div>
                <h1>Contact page</h1>
                <h2>{store.getState().counterState}</h2>
            </div>
        )
    }
}