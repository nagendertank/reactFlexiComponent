import React from "react";

//default import
import Header from "./Header";

import Footer from "./Footer";

import {About} from "./About";


export class ReactExample 
    extends React.Component {

        constructor() {
            super() 

            //react component state
            //reserved word for react state
            this.state = {
                likes: 100000,
                toggle: true
            }

            //override existing increment method
            this.increment = this.increment.bind(this);

        }

        componentWillMount() {
            //this.likes = 100000;
            //this.toggle = true;
        }

        componentDidMount() {
            setInterval(()=> {
                    //state management api
                    //this set the comp state
                    //calls render automatically
                    this.setState({
                        likes: this.state.likes + 1
                    })

                    // this.likes++;
                    // console.log("likes ", this.likes);
                    
                    // //force update,calls  the render view
                    // this.forceUpdate();

            }, 3000);
        }

        toggleHeader(e) {
            console.log("toggle ", e);
            //stop event bubble
            e.stopPropagation();

            //this.toggle = !this.toggle;
            //this.forceUpdate();

            this.setState({
                toggle: !this.state.toggle
            })
        }


        increment() {
            console.log("incr called");
            this.setState({
                likes : this.state.likes + 100
            })
        }
 

        render() {
            return (

               

                <div  onClick={() => console.log("Div click")} >
                   
                    <button onClick={(e) => this.toggleHeader(e)}  >
                        {this.state.toggle == true? "Hide" : "Show"} Header
                    </button>

                    {/* props to pass data from parent 
                    to child  */}
                   {this.state.toggle && <Header title="Shopping App 3" likes={this.state.likes} > 

                   </Header>
                   }
                    <h2>React JSX</h2>
                

                    <About>

                    </About>

                    <Footer  
                            year="2017"  
                            likes={this.state.likes}
                            
                            incr = {this.increment}
                            
                            ></Footer>
                </div>
            )
        }
}