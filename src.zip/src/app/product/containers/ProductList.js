//container component
//higher order component
//wrap existing component

import {connect} from "react-redux";

import * as actions from "../Actions";

import {bindActionCreators} from "redux";

import ProductList
    from "../components/ProductList";

    //state is from store.getState()
    //state has
    //{
       // counterState: 1000 ,
   // mathState : 0 ,
   // productState:   { products: [], loading: false}
    //}
const mapReduxStateToCompProps = (state) => {
    //title, products are props
    //passed to list component
    return {
        title: 'Product List',
        products: state.productState.products
    }
}

const mapReduxDispatchToComponentProps = (dispatch) => {
    //pass dispatch to props
    return {
        productActions: bindActionCreators(actions, dispatch)
       // dispatch: dispatch
    }
}

var connectFn = connect(mapReduxStateToCompProps,
                        mapReduxDispatchToComponentProps);

//container component shall have
//subscribe
//unsubscribe
//pass the redux state to react component properties
var ProductListContainerComponent = connectFn(ProductList);

export default ProductListContainerComponent;