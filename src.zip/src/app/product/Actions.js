import * as ActionTypes from "./ActionTypes";

import * as productService from "./ProductService";
 
//action creators

//create loading action
export function loading() {
    return {
        type: ActionTypes.LOADING
    }
}

//action to get products from web service
export function getProducts() {
    //shall be executed by thunk
    return function(dispatch) {
    
        //ajax, async call
        productService.fetchProducts()
        .then ( products => {
            dispatch( {
                type: ActionTypes.INIT_PRODUCTS,
                products: products
            })
        })
    }
}