import React from "react";

export default class ProductEdit extends React.Component {
    render() {
        return (
            <div>
                <h2>Product Edit</h2>

            </div>
        )
    }
}