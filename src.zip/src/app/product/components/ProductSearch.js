import React from "react";

export default class ProductSearch extends React.Component {
    render() {
        return (
            <div>
                <h2>Product Search</h2>

            </div>
        )
    }
}