import React from "react";

 
export default class ProductList extends React.Component {
    
    componentDidMount() {
        this.props.productActions.getProducts();
    }
    
    render() {

        let list = this.props.products
                   .map ( product => (

                    <li key={product.id}>
                        {product.name}
                    </li>


                   ))

        return (
            <div>
                <h2>Product List</h2>

                <span>{this.props.title}</span>
                <br />
                <span>Total: {this.props.products.length}</span>


                <ul>
                    {list}
                </ul>
            </div>
        )
    }
}