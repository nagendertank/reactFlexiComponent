//all action constants goes here

export const LOADING="LOADING";
export const INIT_PRODUCTS = "INIT_PRODUCTS";
export const INIT_BRANDS = "INIT_BRANDS";
export const EDIT_PRODUCT = "EDIT_PRODUCT";