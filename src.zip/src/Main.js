//this file also can be called index.js

//import {App} from "./app/components/App";

import React from "react";
import {render} from "react-dom";

import Routes from "./app/Routes";

import store from "./app/Store";

//helps to pass store object to connect method
//or container components

import {Provider} from "react-redux"

//mouting react comp into html
render( <Provider  store={store} >
            <Routes> 

            </Routes>
        </Provider>,
    document.getElementById("root"))

    